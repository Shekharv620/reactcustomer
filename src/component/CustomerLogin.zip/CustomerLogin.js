 import React, { Component } from 'react';
import axios from 'axios';
import {Button} from 'react-bootstrap';
import { Redirect } from 'react-router-dom'

export default class CustomerLogin extends Component {
    constructor(props) {
        super(props)
    
        this.initialState = {
             email:"",
             password:"",
             result:{},
             name:""
        }
        this.state=this.initialState;
        this.onSubmitHandler=this.onSubmitHandler.bind(this);
        this.onChangehandler=this.onChangehandler.bind(this);
    }

   onChangehandler(e){
        const name = e.target.name;
        const value = e.target.value;

        this.setState({
            [name]:value
        })
   } 

   onSubmitHandler(e){
        e.preventDefault()
     
        let dic = {
            email:this.state.email,
            password:this.state.password
          }
        axios.post("http://videhjaiswal.pythonanywhere.com/customer/customer_api/customers/login",dic)
        .then(response => {
            console.log(response)
            this.setState({
                name:response.data.name
            })
        }).catch(error => {
            console.log(error)
        })
         
        this.setState(this.initialState)
        console.log(this.state.name)
   } 
    
  render() {


    {
      if (this.state.loggedIn)
      {    
      return <Redirect to= "/Home"/> 
      }

    return (
      <div>
          <h1 style={{color:'red'}}>Customer Login</h1>
          <form onSubmit={this.onSubmitHandler}>
               Email:
               <input type="email" name="email" value={this.state.email}
                onChange={this.onChangehandler}
                placeholder="Enter a Email" /><br></br>
                Password:
               <input type="password" name="password" value={this.state.password}
                onChange={this.onChangehandler}
                placeholder="Enter a Password" /><br></br>
                <Button type="submit" variant="btn btn-primary">
                     Login
                </Button>
          </form>
      </div>
    )
  }
}
}