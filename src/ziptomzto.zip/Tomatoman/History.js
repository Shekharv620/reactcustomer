import React, { Component } from 'react'

export default class History extends Component {
  render() {
    return (
      <div>
           <h1>History</h1>
      </div>
    )
  }
}
