export const addproduct=(data)=>{
    return{
        type: 'ADD_PRODUCT',
        payload: data
      }
}

export const deleteproduct=(product_id)=>{
  return{


    type: 'DELETE_PRODUCT',
    product_id: product_id
  }
}