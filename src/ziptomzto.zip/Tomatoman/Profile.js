import React, { Component } from 'react'
import {Button,Form} from 'react-bootstrap';
import {Link, Redirect} from 'react-router-dom';
export default class Profile extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             fullname:"",
             contact:"",
             address:"",
             landmark:""
        }
        this.onHandleChange=this.onHandleChange.bind(this);
        this.placeOrder=this.placeOrder.bind(this);
    }

    onHandleChange(e){
        const name=e.target.name;
        const value=e.target.value;
        this.setState({
            [name]:value
        })
    }

    componentDidMount(){
       var fullname = localStorage.getItem("fullname",this.state.fullname);
       var contact = localStorage.getItem("contact",this.state.contact);
       var address = localStorage.getItem("address",this.state.address);
       var landmark = localStorage.getItem("landmark",this.state.landmark);
       this.setState({
           fullname:fullname,
           contact:contact,
           address:address,
           landmark:landmark
       })
    }
    
  placeOrder(e)
  {
      e.preventDefault()
      console.log(this.state)
      alert("Your order is placed!!!!")
      localStorage.setItem("fullname",this.state.fullname);
      localStorage.setItem("contact",this.state.contact);
      localStorage.setItem("address",this.state.address);
      localStorage.setItem("landmark",this.state.landmark);
      this.props.history.push('/History');
  }  
  render() {
    return (
      <div>
          <h1>Profile !!!</h1>
          <Form onSubmit={this.placeOrder}>
  <Form.Group controlId="formFullName">
    <Form.Label>FullName:</Form.Label>
    <Form.Control type="text" placeholder="Enter full name" 
    name="fullname"
    value={this.state.fullname}
    onChange={this.onHandleChange} />
  </Form.Group>

  <Form.Group controlId="formContact">
    <Form.Label>Contact:</Form.Label>
    <Form.Control type="text" placeholder="Enter contact"
    name="contact"
    value={this.state.contact}
    onChange={this.onHandleChange} />
  </Form.Group>

  <Form.Group controlId="formAddress">
    <Form.Label>Address:</Form.Label>
    <Form.Control type="text" placeholder="Enter address" 
     name="address"
     value={this.state.address}
     onChange={this.onHandleChange} />
  </Form.Group>

  <Form.Group controlId="formAddress">
    <Form.Label>LandMark:</Form.Label>
    <Form.Control type="text" placeholder="Enter landmark" 
    name="landmark"
    value={this.state.landmark}
    onChange={this.onHandleChange}/>u
  </Form.Group>
  
  <Button variant="primary" type="submit">
    Order
  </Button>
</Form>
      </div>
    )
  }
}
